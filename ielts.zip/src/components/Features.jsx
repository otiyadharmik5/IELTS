export default function Features() {
  const features = [
    { title: "Experienced Teachers", icon: "✅" },
    { title: "Global Recognition", icon: "🌐" },
    { title: "Comprehensive Courses", icon: "📘" },
  ];
  return (
    <section className="py-16 bg-gray-50 text-center">
      <h3 className="text-3xl font-bold text-blue-900 mb-4">Features</h3>
      <p className="text-gray-600 max-w-xl mx-auto mb-10">
        Lorem ipsum dolor sit amet, consectetur adipiscing elit.
      </p>
      <div className="grid gap-8 md:grid-cols-3 max-w-5xl mx-auto">
        {features.map((f) => (
          <div key={f.title} className="p-6 bg-white rounded-lg shadow">
            <div className="text-4xl mb-4">{f.icon}</div>
            <h4 className="text-xl font-semibold">{f.title}</h4>
            <p className="text-gray-600 mt-2">
              Lorem ipsum dolor sit amet, consectetur ad.
            </p>
          </div>
        ))}
      </div>
    </section>
  );
}
