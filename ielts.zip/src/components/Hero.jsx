import heroImg from "../assets/hero.jpg";

export default function Hero() {
  return (
    <section className="bg-white py-16 px-6 md:flex md:items-center md:justify-between">
      <div className="max-w-lg">
        <h2 className="text-4xl md:text-5xl font-bold text-blue-900 mb-4">
          Improve Your English Skills with Our IELTS Institute
        </h2>
        <p className="text-gray-600 mb-6">
          Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc aliquet,
          turpis a commodo dignissim.
        </p>
        <button className="bg-red-600 text-white px-6 py-3 rounded-md hover:bg-red-700">
          Get Started
        </button>
      </div>
      <img
        src={heroImg}
        alt="Student"
        className="mt-8 md:mt-0 md:w-1/2 rounded-lg shadow"
      />
    </section>
  );
}
