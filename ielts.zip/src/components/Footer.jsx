export default function Footer() {
  return (
    <footer className="bg-blue-900 text-white py-6 text-center">
      <p>© {new Date().getFullYear()} IELTS Institute. All rights reserved.</p>
    </footer>
  );
}
