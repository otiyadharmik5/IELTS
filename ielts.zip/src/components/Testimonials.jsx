export default function Testimonials() {
  return (
    <section className="py-16 text-center">
      <h3 className="text-3xl font-bold text-blue-900 mb-8">Testimonials</h3>
      <blockquote className="max-w-xl mx-auto bg-gray-100 p-6 rounded-lg">
        <p className="italic text-gray-700 mb-4">
          “Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nunc ipsum
          sem, bibendum at tellus id, sagittis sagittis dolor.”
        </p>
        <span className="font-semibold text-blue-700">— John Doe</span>
      </blockquote>
    </section>
  );
}
