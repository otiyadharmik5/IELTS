export default function Navbar() {
  return (
    <nav className="flex justify-between items-center px-6 py-4 bg-white shadow">
      <h1 className="text-2xl font-bold text-blue-700">IELTS Institute</h1>
      <ul className="hidden md:flex space-x-6 text-gray-700">
        <li className="hover:text-blue-700 cursor-pointer">Home</li>
        <li className="hover:text-blue-700 cursor-pointer">About</li>
        <li className="hover:text-blue-700 cursor-pointer">Services</li>
        <li className="hover:text-blue-700 cursor-pointer">Contact</li>
      </ul>
    </nav>
  );
}
